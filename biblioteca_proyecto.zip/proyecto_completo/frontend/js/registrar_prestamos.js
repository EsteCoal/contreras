function registrar_Prestamoss(){
    var id_prestamo = document.getElementById("id_prestamo").value;
    var fecha_prestamo = document.getElementById("fecha_prestamo").value;
    var fecha_devolucion = document.getElementById("fecha_devolucion").value;
    var estado = document.getElementById("estado").value;
    var condiciones = document.getElementById("condiciones").value;
    var notas = document.getElementById("notas").value;
    var libros_isbn = document.getElementById("libros_isbn").value;
    var alumno_idalumno= document.getElementById("alumno_idalumno").value;
  
    console.log(id_prestamo,fecha_prestamo,fecha_devolucion,estado,condiciones,libros_isbn,alumno_idalumno)

    var details = {
        id_prestamo:id_prestamo,
        fecha_prestamo:fecha_prestamo,
        fecha_devolucion:fecha_devolucion,
        estado:estado,
        condiciones:condiciones,
        notas:notas,
        libros_isbn:libros_isbn,
        alumno_idalumno:alumno_idalumno
    };

    var formBody = [];
    for (var property in details) {
      var encodedKey = encodeURIComponent(property);
      var encodedValue = encodeURIComponent(details[property]);
      formBody.push(encodedKey + "=" + encodedValue);
    }
    formBody = formBody.join("&");

    console.log(formBody);
    
    fetch('http://localhost:8080/autores/registrarPrestamo', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
      },
      body: formBody
    })
    .then(response => response.json())
    .then(data => {
        console.log(data);
    })
}