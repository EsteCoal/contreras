window.onload = function () {
    Obtener_Autores();
  }
function Obtener_Autores() {
    
    fetch('http://localhost:8080/autores/obtenerAutor', {
      method: 'GET',
    })
      .then(response => response.json())
      .then(data => {
  
        console.log(data);
  
        var cuerpo_autor = document.getElementById('cuerpo_autor');
          
        for (var i = 0; i < data.length; i++) {
          var tr = document.createElement('tr');
  
          var button = document.createElement("input");
          button.type = 'button';
          button.id = data[i].id_autor;
          button.value = data[i].id_autor;
          button.style.border = "none";
          button.style.backgroundColor = "transparent";
          
          var celda = document.createElement('td')
          celda.appendChild(button);

          var celda2 = document.createElement('td')
          celda2.innerHTML = data[i].nombre;

          var celda3 = document.createElement('td')
          celda3.innerHTML = data[i].ap_materno;

          var celda4 = document.createElement('td')
          celda4.innerHTML = data[i].ap_paterno;

          var celda5 = document.createElement('td')
          celda5.innerHTML = data[i].nacionalidad;


  
          tr.appendChild(celda);
          tr.appendChild(celda2);
          tr.appendChild(celda3);
          tr.appendChild(celda4);
          tr.appendChild(celda5);
          cuerpo_autor.appendChild(tr);
          }
      })
  }
