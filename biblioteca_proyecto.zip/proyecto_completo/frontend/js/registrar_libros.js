function registrar_Libross(){
    var isbn = document.getElementById("isbn").value;
    var titulo = document.getElementById("titulo").value;
    var anio_publicacion = document.getElementById("anio_publicacion").value;
    var existencias = document.getElementById("existencias").value;
    var editorial = document.getElementById("editorial").value;
    var ubicacion_numero_ubicacion = document.getElementById("ubicacion_numero_ubicacion").value;
    var autores_id_autor = document.getElementById("autores_id_autor").value;

    console.log(isbn,titulo,anio_publicacion,existencias,editorial,ubicacion_numero_ubicacion,autores_id_autor)

    var details = {
        isbn:isbn,
        titulo:titulo,
        anio_publicacion:anio_publicacion,
        existencias:existencias,
        editorial:editorial,
        ubicacion_numero_ubicacion,ubicacion_numero_ubicacion,
        autores_id_autor,autores_id_autor
    };

    var formBody = [];
    for (var property in details) {
      var encodedKey = encodeURIComponent(property);
      var encodedValue = encodeURIComponent(details[property]);
      formBody.push(encodedKey + "=" + encodedValue);
    }
    formBody = formBody.join("&");

    console.log(formBody);
    
    fetch('http://localhost:8080/autores/registrarLibro', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
      },
      body: formBody
    })
    .then(response => response.json())
    .then(data => {
        console.log(data);
    })
}