window.onload = function () {
    Obtener_Libros();
  }
  
function Obtener_Libros() {
    
    fetch('http://localhost:8080/autores/obtenerLibro', {
      method: 'GET',
    })
      .then(response => response.json())
      .then(data => {
  
        console.log(data);
  
        var cuerpo_Libro = document.getElementById('cuerpo_Libro');
          
        for (var i = 0; i < data.length; i++) {
          var tr = document.createElement('tr');
  
          var button = document.createElement("input");
          button.type = 'button';
          button.id = data[i].isbn;
          button.value = data[i].isbn;
          button.style.border = "none";
          button.style.backgroundColor = "transparent";
          
          var celda = document.createElement('td')
          celda.appendChild(button);

          var celda2 = document.createElement('td')
          celda2.innerHTML = data[i].titulo;

          var celda3 = document.createElement('td')
          celda3.innerHTML = data[i].anio_publicacion;

          var celda4 = document.createElement('td')
          celda4.innerHTML = data[i].existencias;

          var celda5 = document.createElement('td')
          celda5.innerHTML = data[i].editorial;

          var celda6 = document.createElement('td')
          celda6.innerHTML = data[i].ubicacion_numero_ubicacion;

          var celda7 = document.createElement('td')
          celda7.innerHTML = data[i].autores_id_autor.nombre;
  
          tr.appendChild(celda);
          tr.appendChild(celda2);
          tr.appendChild(celda3);
          tr.appendChild(celda4);
          tr.appendChild(celda5);
          tr.appendChild(celda6);
          tr.appendChild(celda7);

          cuerpo_Libro.appendChild(tr);
          }
      })
  }
