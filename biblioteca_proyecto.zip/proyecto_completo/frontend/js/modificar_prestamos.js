function EstablecerDatos_Prestamos(){
  
    document.getElementById("id_prestamo").value = sessionStorage.getItem('id_prestamo');
    document.getElementById("fecha_prestamo").value = sessionStorage.getItem('fecha_prestamp');
    document.getElementById("fecha_devolucion").value = sessionStorage.getItem('fecha_devolucion');
    document.getElementById("estado").value = sessionStorage.getItem('estado');
    document.getElementById("condiciones").value = sessionStorage.getItem('condiciones');
    document.getElementById("notas").value = sessionStorage.getItem('notas');
    document.getElementById("libros_isbn").value = sessionStorage.getItem('libros_isbn');
    document.getElementById("alumno_idalumno").value = sessionStorage.getItem('alumno_idalumno');
  }
  function modificar_Prestamos(){
    var id_prestamo = document.getElementById("id_prestamo").value;
    var fecha_prestamo = document.getElementById("fecha_prestamo").value;
    var fecha_devolucion = document.getElementById("fecha_devolucion").value;
    var estado = document.getElementById("estado").value;
    var condiciones  = document.getElementById("condiciones").value;
    var notas  = document.getElementById("notas").value;
    var libros_isbn  = document.getElementById("libros_isbn").value;
    var alumno_idalumno=document.getElementById("alumno_idalumno").value;

  
    console.log(id_prestamo,fecha_prestamo,fecha_devolucion,estado,condiciones,notas,libros_isbn,alumno_idalumno)
  
    var details = {
        id_prestamo:id_prestamo,
        fecha_prestamo:fecha_prestamo,
        fecha_devolucion:fecha_devolucion,
        estado:estado,
        condiciones:condiciones,
        notas:notas,
        libros_isbn:libros_isbn,
        alumno_idalumno:alumno_idalumno
    };
  
    var formBody = [];
    for (var property in details) {
      var encodedKey = encodeURIComponent(property);
      var encodedValue = encodeURIComponent(details[property]);
      formBody.push(encodedKey + "=" + encodedValue);
    }
    formBody = formBody.join("&");
  
    console.log(formBody);
    
    fetch('http://localhost:8080/autores/modificarPrestamo', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
      },
      body: formBody
    })
    .then(response => response.json())
    .then(data => {
        console.log(data);
    })
  
  }
  function eliminar_Prestamos() {
    
    var id = document.getElementById("id_prestamo").value;
        
    fetch('http://localhost:8080/autores/eliminarPrestamo/' + id , {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
      },
      body: id,
    })
  }