window.onload = function () {
    EstablecerDatosAutores();
}
function EstablecerDatosAutores(){
  
    document.getElementById("id_autor").value = sessionStorage.getItem('id_autor');
    document.getElementById("nombre").value = sessionStorage.getItem('nombre');
    document.getElementById("ap_materno").value = sessionStorage.getItem('ap_materno');
    document.getElementById("ap_paterno").value = sessionStorage.getItem('ap_paterno');
    document.getElementById("nacionalidad").value = sessionStorage.getItem('nacionalidad');
}
function modificar_Autores(){
    var id_autor = document.getElementById("id_autor").value;
    var nombre = document.getElementById("nombre").value;
    var ap_materno = document.getElementById("ap_materno").value;
    var ap_paterno = document.getElementById("ap_paterno").value;
    var nacionalidad  = document.getElementById("nacionalidad").value;

    console.log(id_autor,nombre,ap_materno,ap_paterno,nacionalidad)

    var details = {
        id_autor:id_autor,
        nombre:nombre,
        ap_materno:ap_materno,
        ap_paterno:ap_paterno,
        nacionalidad:nacionalidad
    };

    var formBody = [];
    for (var property in details) {
      var encodedKey = encodeURIComponent(property);
      var encodedValue = encodeURIComponent(details[property]);
      formBody.push(encodedKey + "=" + encodedValue);
    }
    formBody = formBody.join("&");

    console.log(formBody);
    
    fetch('http://localhost:8080/autores/modificarAutor', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
      },
      body: formBody
    })
    .then(response => response.json())
    .then(data => {
        console.log(data);
    })

}
function eliminar_Autores() {
    
    var id = document.getElementById("id_autor").value;
        
    fetch('http://localhost:8080/autores/eliminarAutor/' + id , {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
      },
      body: id,
    })
}

