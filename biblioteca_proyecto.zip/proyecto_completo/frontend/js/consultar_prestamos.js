var Prestamos = [];

window.onload = function () {
    Obtener_Prestamo();
  }
  
function Obtener_Prestamo() {
    
    fetch('http://localhost:8080/autores/obtenerPrestamo', {
      method: 'GET',
    })
      .then(response => response.json())
      .then(data => {
  
        console.log(data);
  
        var cuerpo_prestamo = document.getElementById('cuerpo_prestamo');
          
        for (var i = 0; i < data.length; i++) {
          var tr = document.createElement('tr');
  
          var button = document.createElement("input");
          button.type = 'button';
          button.id = data[i].id_prestamo;
          button.value = data[i].id_prestamo;
          button.style.border = "none";
          button.style.backgroundColor = "transparent";
          
          var celda = document.createElement('td')
          celda.appendChild(button);

          var celda2 = document.createElement('td')
          celda2.innerHTML = data[i].fecha_prestamo;

          var celda3 = document.createElement('td')
          celda3.innerHTML = data[i].fecha_devolucion;

          var celda4 = document.createElement('td')
          celda4.innerHTML = data[i].estado;

          var celda5 = document.createElement('td')
          celda5.innerHTML = data[i].condiciones;

          var celda6 = document.createElement('td')
          celda6.innerHTML = data[i].notas;

          var celda7 = document.createElement('td')
          celda7.innerHTML = data[i].libros_isbn.isbn;

          var celda8 = document.createElement('td')
          celda8.innerHTML = data[i].alumno_idalumno.idalumno;
  
          tr.appendChild(celda);
          tr.appendChild(celda2);
          tr.appendChild(celda3);
          tr.appendChild(celda4);
          tr.appendChild(celda5);
          tr.appendChild(celda6);
          tr.appendChild(celda7);
          tr.appendChild(celda8);

          cuerpo_prestamo.appendChild(tr);
          }
      })
  }
