function registrar_Alumnos(){
    var idalumno = document.getElementById("idalumno").value;
    var nombre_Completo = document.getElementById("nombre_Completo").value;
    var semestre = document.getElementById("semestre").value;
    var licenciatura = document.getElementById("licenciatura").value;

    console.log(idalumno,nombre_Completo,semestre,licenciatura)

    var details = {
        idalumno:idalumno,
        nombre_Completo:nombre_Completo,
        semestre:semestre,
        licenciatura:licenciatura
    };

    var formBody = [];
    for (var property in details) {
      var encodedKey = encodeURIComponent(property);
      var encodedValue = encodeURIComponent(details[property]);
      formBody.push(encodedKey + "=" + encodedValue);
    }
    formBody = formBody.join("&");

    console.log(formBody);
    
    fetch('http://localhost:8080/autoress/registrarAlumnoss', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
      },
      body: formBody
    })
    .then(response => response.json())
    .then(data => {
        console.log("data: " + data);
    })
}