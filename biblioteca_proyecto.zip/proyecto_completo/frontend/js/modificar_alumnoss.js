window.onload = function () {
    EstablecerDatos();
}
function EstablecerDatos(){
  
    document.getElementById("idalumno").value = sessionStorage.getItem('idalumno');
    document.getElementById("nombre_Completo").value = sessionStorage.getItem('nombre_Completo');
    document.getElementById("semestre").value = sessionStorage.getItem('semestre');
    document.getElementById("licenciatura").value = sessionStorage.getItem('licenciatura');

}
function modificar_Alumnos(){
    var idalumno = document.getElementById("idalumno").value;
    var nombre_Completo = document.getElementById("nombre_Completo").value;
    var semestre = document.getElementById("semestre").value;
    var licenciatura = document.getElementById("licenciatura").value;

    console.log(idalumno,nombre_Completo,semestre,licenciatura)

    var details = {
        idalumno:idalumno,
        nombre_Completo:nombre_Completo,
        semestre:semestre,
        licenciatura:licenciatura
    };

    var formBody = [];
    for (var property in details) {
      var encodedKey = encodeURIComponent(property);
      var encodedValue = encodeURIComponent(details[property]);
      formBody.push(encodedKey + "=" + encodedValue);
    }
    formBody = formBody.join("&");

    console.log(formBody);
    
    fetch('http://localhost:8080/autoress/modificarAlumno', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
      },
      body: formBody
    })
    .then(response => response.json())
    .then(data => {
        console.log(data);
    })

}
function eliminar_Alumnos() {
    
    var id = document.getElementById("idalumno").value;
        
    fetch('http://localhost:8080/autoress/eliminarAlumno/' + id , {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
      },
      body: id,
    })
}


function EstablecerDatos_Prestamos(){
  document.getElementById("id_prestamo").value = sessionStorage.getItem('id_prestamo');
  document.getElementById("fecha_prestamo").value = sessionStorage.getItem('fecha_prestamo');
  document.getElementById("fecha_devolucion").value = sessionStorage.getItem('fecha_devolucion');
  document.getElementById("estado").value = sessionStorage.getItem('estado');
  document.getElementById("condiciones").value = sessionStorage.getItem('condiciones');
  document.getElementById("notas").value = sessionStorage.getItem('notas');
  document.getElementById("libros_isbn").value = sessionStorage.getItem('libros_isbn');
  document.getElementById("alumno_idalumno").value = sessionStorage.getItem('alumno_idalumno');
}
  function modificar_Prestamos(){
  var id_prestamo = document.getElementById("id_prestamo").value;
  var fecha_prestamo = document.getElementById("fecha_prestamo").value;
  var fecha_devolucion = document.getElementById("fecha_devolucion").value;
  var estado = document.getElementById("estado").value;
  var condiciones = document.getElementById("condiciones").value;
  var notas = document.getElementById("notas").value;
  var libros_isbn = document.getElementById("libros_isbn").value;
  var alumno_idalumno = document.getElementById("alumno_idalumno").value;

  console.log(id_prestamo,fecha_prestamo,fecha_devolucion,estado,condiciones,notas,libros_isbn,alumno_idalumno)

  var details = {
      id_prestamo:id_prestamo,
      fecha_prestamo:fecha_prestamo,
      fecha_devolucion:fecha_devolucion,
      estado:estado,
      condiciones:condiciones,
      notas:notas,
      libros_isbn,libros_isbn,
      alumno_idalumno,alumno_idalumno
  };

  var formBody = [];
  for (var property in details) {
    var encodedKey = encodeURIComponent(property);
    var encodedValue = encodeURIComponent(details[property]);
    formBody.push(encodedKey + "=" + encodedValue);
  }
  formBody = formBody.join("&");

  console.log(formBody);
  
  fetch('http://localhost:8080/autoress/modificarPrestamos', {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
    },
    body: formBody
  })
  .then(response => response.json())
  .then(data => {
      console.log(data);
  })

}
function eliminar_Prestamos() {
  
  var id = document.getElementById("id_prestamo").value;
      
  fetch('http://localhost:8080/autoress/eliminarPrestamos/' + id , {
    method: 'DELETE',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
    },
    body: id,
  })
}