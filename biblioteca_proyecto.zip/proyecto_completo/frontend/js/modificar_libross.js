function EstablecerDatos_Libros(){
  
    document.getElementById("isbn").value = sessionStorage.getItem('isbn');
    document.getElementById("titulo").value = sessionStorage.getItem('titulo');
    document.getElementById("anio_publicacion").value = sessionStorage.getItem('anio_publicacion');
    document.getElementById("existencias").value = sessionStorage.getItem('existencias');
    document.getElementById("editorial").value = sessionStorage.getItem('editorial');
    document.getElementById("ubicacion_numero_ubicacion").value = sessionStorage.getItem('ubicacion_numero_ubicacion');
    document.getElementById("autores_id_autor").value = sessionStorage.getItem('autores_id_autor');
  }
  function modificar_Libros(){
    var isbn = document.getElementById("isbn").value;
    var titulo = document.getElementById("titulo").value;
    var anio_publicacion = document.getElementById("anio_publicacion").value;
    var existencias = document.getElementById("existencias").value;
    var editorial  = document.getElementById("editorial").value;
    var ubicacion_numero_ubicacion  = document.getElementById("ubicacion_numero_ubicacion").value;
    var autores_id_autor  = document.getElementById("autores_id_autor").value;
  
    console.log(isbn,titulo,anio_publicacion,existencias,editorial,ubicacion_numero_ubicacion,autores_id_autor)
  
    var details = {
        isbn:isbn,
        titulo:titulo,
        anio_publicacion:anio_publicacion,
        existencias:existencias,
        editorial:editorial,
        ubicacion_numero_ubicacion:ubicacion_numero_ubicacion,
        autores_id_autor:autores_id_autor
    };
  
    var formBody = [];
    for (var property in details) {
      var encodedKey = encodeURIComponent(property);
      var encodedValue = encodeURIComponent(details[property]);
      formBody.push(encodedKey + "=" + encodedValue);
    }
    formBody = formBody.join("&");
  
    console.log(formBody);
    
    fetch('http://localhost:8080/autores/modificarLibro', {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
      },
      body: formBody
    })
    .then(response => response.json())
    .then(data => {
        console.log(data);
    })
  
  }
  function eliminar_Libros() {
    
    var id = document.getElementById("isbn").value;
        
    fetch('http://localhost:8080/autores/eliminarLibro/' + id , {
      method: 'DELETE',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
      },
      body: id,
    })
  }