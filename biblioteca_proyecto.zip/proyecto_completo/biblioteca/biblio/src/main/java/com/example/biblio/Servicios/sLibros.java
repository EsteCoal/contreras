package com.example.biblio.Servicios;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.biblio.Objetos.rLibros;
import com.example.biblio.Repositorios.rRepositoriosLibros;
@Service
public class sLibros {
    @Autowired
    rRepositoriosLibros LibrosRepositorio;
    rLibros LibrosP = new rLibros();

    public rLibros registrarLibros(rLibros libross){
        if (LibrosRepositorio.existsById(libross.getIsbn())){
            return LibrosP;
        }
        else {
            return LibrosRepositorio.save(libross);
        }
    }

    public List<rLibros> obtenerLibros(){
        return LibrosRepositorio.findAll();
    }

    public rLibros modificarLibros(rLibros libross){
        if(LibrosRepositorio.existsById(libross.getIsbn())){
            return LibrosRepositorio.save(libross);
        }else{
            return LibrosP;
        }
    }

    public void eliminarLibros(Integer id){
        LibrosRepositorio.deleteById(id);
    }
}