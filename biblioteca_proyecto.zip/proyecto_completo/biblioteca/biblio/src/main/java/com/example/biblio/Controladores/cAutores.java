package com.example.biblio.Controladores;
import java.util.List;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.biblio.Objetos.rAutor;
import com.example.biblio.Servicios.sAutores;

@RestController
@RequestMapping("/autores")
public class cAutores {
    @Autowired
    sAutores registrarAutoresServicio;

    @PostMapping(path = "/registrarAutor", consumes = {MediaType.APPLICATION_FORM_URLENCODED_VALUE})
    public rAutor registrarAutores(rAutor autors){
        
        return registrarAutoresServicio.registrarAutores(autors);
    }

    @CrossOrigin
    @PutMapping(path = "/modificarAutor", consumes = {MediaType.APPLICATION_FORM_URLENCODED_VALUE})
    public rAutor modificarAutores(rAutor autors){
        return registrarAutoresServicio.modificarAutores(autors);
    }
    @GetMapping("/obtenerAutor")
    public List<rAutor> obtenerAutors(){
        return registrarAutoresServicio.obtenerAutors();
    }

    @DeleteMapping("/eliminarAutor/{id}")
    @CrossOrigin
    public void eliminarAutor(@PathVariable Integer id){
        registrarAutoresServicio.eliminarAutor(id);
    }

}
