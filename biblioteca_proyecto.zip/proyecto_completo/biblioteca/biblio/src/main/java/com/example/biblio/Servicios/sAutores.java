package com.example.biblio.Servicios;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.biblio.Objetos.rAutor;
import com.example.biblio.Repositorios.rRepositoriosAutores;
@Service
public class sAutores {
    @Autowired
    rRepositoriosAutores autoresRepositorio;
    rAutor AutorP = new rAutor();

    public rAutor registrarAutores(rAutor autors){

        if(autoresRepositorio.existsById(autors.getId_autor())){
            return AutorP;
        }
        else{
            return autoresRepositorio.save(autors);
            
        }
    }

    public List<rAutor> obtenerAutors(){
        return autoresRepositorio.findAll();
    }

    public rAutor modificarAutores(rAutor autors){
        if(autoresRepositorio.existsById(autors.getId_autor())){
            return autoresRepositorio.save(autors);
        }else{
            return AutorP;
        }
    }

    public void eliminarAutor(Integer id){
        autoresRepositorio.deleteById(id);
    }
}
