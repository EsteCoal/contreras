package com.example.biblio.Servicios;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.biblio.Objetos.rPrestamos;
import com.example.biblio.Repositorios.rRepositoriosPrestamos;
@Service
public class sPrestamos{
    @Autowired
    rRepositoriosPrestamos PrestamosRepositorio;
    rPrestamos PrestamosP = new rPrestamos();

    public rPrestamos registrarPrestamos(rPrestamos prestamoss){
        
        if(PrestamosRepositorio.existsById(prestamoss.getId_prestamo())){
            return PrestamosP;
        }
        else{
            return PrestamosRepositorio.save(prestamoss);
            
        }
    }

    public rPrestamos modificarPrestamos(rPrestamos prestamoss){
        if(PrestamosRepositorio.existsById(prestamoss.getId_prestamo())){
            return PrestamosRepositorio.save(prestamoss);
        }else{
            return PrestamosP;
        }
    }

    public List<rPrestamos> obtenerPrestamos(){
        return PrestamosRepositorio.findAll();
    }

    public void eliminarPrestamos(Integer id){
        PrestamosRepositorio.deleteById(id);
    }
}