package com.example.biblio.Objetos;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "alumno")
public class rAlumnos {
    @Id
    @Column(name="idalumno",nullable = false, unique = true)
    private Integer idalumno;

    @Column(name="nombre_Completo", nullable = false, unique = false)
    private String nombre_Completo;

    @Column(name="semestre",nullable = false, unique = false)
    private String semestre;

    @Column(name="licenciatura",nullable = false, unique = false)
    private String licenciatura ;
}

