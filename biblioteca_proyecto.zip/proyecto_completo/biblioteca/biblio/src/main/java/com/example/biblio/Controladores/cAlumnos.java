package com.example.biblio.Controladores;
import java.util.List;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.biblio.Objetos.rAlumnos;
import com.example.biblio.Servicios.sAlumnos;

@RestController
@RequestMapping("/autoress")
public class cAlumnos {
    @Autowired
    sAlumnos registrarAlumnosServicio;

    @PostMapping(path = "/registrarAlumnoss", consumes = {MediaType.APPLICATION_FORM_URLENCODED_VALUE})
    public rAlumnos registrarAlumnos(rAlumnos alumnos){
        
        return registrarAlumnosServicio.registrarAlumnos(alumnos);
    }
    
    @CrossOrigin
    @PutMapping(path = "/modificarAlumno", consumes = {MediaType.APPLICATION_FORM_URLENCODED_VALUE})
    public rAlumnos modificarAlumnos(rAlumnos alumnos){
        return registrarAlumnosServicio.modificarAlumnos(alumnos);
    }
    @GetMapping("/obtenerAlumno")
    public List<rAlumnos> obtenerAlumno(){
        return registrarAlumnosServicio.obtenerAlumnos();
    }

    @DeleteMapping("/eliminarAlumno/{id}")
    @CrossOrigin
    public void eliminarAlumnos(@PathVariable Integer id){
        registrarAlumnosServicio.eliminarAlumnos(id);
    }

}

