package com.example.biblio.Controladores;
import java.util.List;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.biblio.Objetos.rLibros;
import com.example.biblio.Servicios.sLibros;

@RestController
@RequestMapping("/autores")
public class cLibros {
    @Autowired
    sLibros registrarLibrosServicio;

    @PostMapping(path = "/registrarLibro", consumes = {MediaType.APPLICATION_FORM_URLENCODED_VALUE})
    public rLibros registrarLibros(rLibros libross){
        
        return registrarLibrosServicio.registrarLibros(libross);
    }

    @CrossOrigin
    @PutMapping(path = "/modificarLibro", consumes = {MediaType.APPLICATION_FORM_URLENCODED_VALUE})
    public rLibros modificarLibros(rLibros libross){
        return registrarLibrosServicio.modificarLibros(libross);
    }
    
    @GetMapping("/obtenerLibro")    
    public List<rLibros> obtenerLibros()
    {
         return registrarLibrosServicio.obtenerLibros();
        }
    @DeleteMapping("/eliminarLibro/{id}")
    @CrossOrigin
    public void eliminarLibro(@PathVariable Integer id){
        registrarLibrosServicio.eliminarLibros(id);
    }

}

