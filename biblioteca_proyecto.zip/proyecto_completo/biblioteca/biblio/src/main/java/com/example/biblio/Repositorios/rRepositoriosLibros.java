package com.example.biblio.Repositorios;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.biblio.Objetos.rLibros;

@Repository
public interface rRepositoriosLibros extends JpaRepository<rLibros,Integer>{
    
}
