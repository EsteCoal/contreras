package com.example.biblio.Objetos;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "prestamo")
public class rPrestamos
 {
    @Id
    @Column(name="id_prestamo",nullable = false, unique = true)
    private Integer id_prestamo ;

    @Column(name="fecha_prestamo",nullable = false, unique = true)
    private String fecha_prestamo ;

    @Column(name="fecha_devolucion", nullable = false, unique = false)
    private String fecha_devolucion;

    @Column(name="estado",nullable = false, unique = false)
    private String estado ;

    @Column(name="condiciones",nullable = false, unique = false)
    private String condiciones ;

    @Column(name="notas",nullable = false, unique = false)
    private String notas;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "libros_isbn", referencedColumnName = "isbn", nullable = true)
    private rLibros libros_isbn;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "alumno_idalumno", referencedColumnName = "idalumno", nullable = true)
    private rAlumnos alumno_idalumno;
}

