package com.example.biblio.Objetos;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "libro")
public class rLibros {
    @Id
    @Column(name="isbn",nullable = false, unique = true)
    private Integer isbn ;

    @Column(name="titulo", nullable = false, unique = false)
    private String titulo;

    @Column(name="anio_publicacion",nullable = false, unique = false)
    private Integer anio_publicacion ;

    @Column(name="existencias",nullable = false, unique = false)
    private Integer existencias ;

    @Column(name="editorial",nullable = false, unique = false)
    private String editorial;

     @Column(name="ubicacion_numero_ubicacion",nullable = false, unique = false)
    private Integer ubicacion_numero_ubicacion;

    @ManyToOne(fetch = FetchType.EAGER) 
    @JoinColumn(name = "autores_id_autor", referencedColumnName = "id_autor", nullable = false) 
    private rAutor autores_id_autor;
}
    
