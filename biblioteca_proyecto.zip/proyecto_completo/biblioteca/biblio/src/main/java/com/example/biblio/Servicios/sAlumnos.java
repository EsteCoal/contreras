package com.example.biblio.Servicios;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.biblio.Objetos.rAlumnos;
import com.example.biblio.Repositorios.rRepositoriosAlumnos;
@Service
public class sAlumnos {
    @Autowired
    rRepositoriosAlumnos AlumnosRepositorio;
    rAlumnos AlumnosP = new rAlumnos();

    public rAlumnos registrarAlumnos(rAlumnos alumnoss){
        if (AlumnosRepositorio.existsById(alumnoss.getIdalumno())){
            return AlumnosP;
        }
        else {
            return AlumnosRepositorio.save(alumnoss);
        }
    }

    public List<rAlumnos> obtenerAlumnos(){
        return AlumnosRepositorio.findAll();
    }

    public rAlumnos modificarAlumnos(rAlumnos alumnoss){
        if(AlumnosRepositorio.existsById(alumnoss.getIdalumno())){
            return AlumnosRepositorio.save(alumnoss);
        }else{
            return AlumnosP;
        }
    }

    public void eliminarAlumnos(Integer id){
        AlumnosRepositorio.deleteById(id);
    }
}