package com.example.biblio.Repositorios;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.biblio.Objetos.rAutor;

@Repository
public interface rRepositoriosAutores extends JpaRepository<rAutor,Integer>{
    
}
