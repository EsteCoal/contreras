package com.example.biblio.Objetos;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "autor")
public class rAutor {
    @Id
    @Column(name="id_autor",nullable = false, unique = true)
    private Integer id_autor ;

    @Column(name="nombre", nullable = false, unique = false)
    private String nombre;

    @Column(name="ap_materno",nullable = false, unique = false)
    private String ap_materno ;

    @Column(name="ap_paterno",nullable = false, unique = false)
    private String ap_paterno ;

    @Column(name="nacionalidad",nullable = false, unique = false)
    private String nacionalidad;
}
