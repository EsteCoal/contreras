package com.example.biblio.Controladores;
import java.util.List;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.biblio.Objetos.rPrestamos;
import com.example.biblio.Servicios.sPrestamos;

@RestController
@RequestMapping("/autores")
public class cPrestamos {
    @Autowired
    sPrestamos registrarPrestamosServicio;
    @PostMapping(path = "/registrarPrestamo", consumes = {MediaType.APPLICATION_FORM_URLENCODED_VALUE})
    public rPrestamos registrarPrestamos(rPrestamos prestamoss){
        return registrarPrestamosServicio.registrarPrestamos(prestamoss);
    }

    
    @CrossOrigin
    @PutMapping(path = "/modificarPrestamo", consumes = {MediaType.APPLICATION_FORM_URLENCODED_VALUE})
    public rPrestamos modificarPrestamos(rPrestamos prestamoss){
        return registrarPrestamosServicio.modificarPrestamos(prestamoss);
    }
    @GetMapping("/obtenerPrestamo")
    public List<rPrestamos> obtenerPrestamos(){
        return registrarPrestamosServicio.obtenerPrestamos();
    }

    @DeleteMapping("/eliminarPrestamo/{id}")
    @CrossOrigin
    public void eliminarPrestamos(@PathVariable Integer id){
        registrarPrestamosServicio.eliminarPrestamos(id);
    }

}

